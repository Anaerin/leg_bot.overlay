/// <reference path="globals/node/index.d.ts" />
/// <reference path="globals/open/index.d.ts" />
/// <reference path="globals/websocket/index.d.ts" />
