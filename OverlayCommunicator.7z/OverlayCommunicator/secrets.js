﻿module.exports = {
    StreamTip: {
        clientID: '729008e6cbc23138bde6993c3b6ee25e',
        clientSecret: '76f676ea91dcd2ce398387507ad1c624',
        redirectURL: 'http://localhost:8000/code'
    },
    Twitch: {
		clientID: "rlva2gkraaq3jn9w69fm9jwt7vlg045",
		clientSecret: "mjuefd797wsglkwy9nx1ruiwyz7q3n9",
		redirectURL: "http://localhost:8000/code"
    }
}